<?php
session_start();
if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>AV Equipment Entry Form</title>
  <style>
    .form-container {
      max-width: 800px;
      margin: 20px auto;
      padding: 20px;
      background: #f9f9f9;
      border-radius: 8px;
      box-shadow: 0 0 10px rgba(0,0,0,0.1);
    }

    .form-group {
      margin-bottom: 15px;
    }

    .form-group label {
      display: block;
      margin-bottom: 5px;
      font-weight: bold;
    }

    .form-group input,
    .form-group textarea,
    .form-group select {
      width: 100%;
      padding: 8px;
      border: 1px solid #ddd;
      border-radius: 4px;
      background-color: white;
    }

    .date-group {
      display: flex;
      gap: 15px;
    }

    .date-group .form-group {
      flex: 1;
    }

    .button-group {
      display: flex;
      justify-content: space-between;
      margin-top: 20px;
    }

    .btn {
      padding: 10px 15px;
      border: none;
      border-radius: 4px;
      cursor: pointer;
      text-decoration: none;
      text-align: center;
    }

    .btn-primary {
      background-color: #007bff;
      color: white;
    }

    .btn-secondary {
      background-color: #6c757d;
      color: white;
    }

    .btn-danger {
      background-color: #dc3545;
      color: white;
    }

    .welcome-message {
      text-align: center;
      margin-bottom: 20px;
    }
  </style>
</head>
<body>
  <div class="form-container">
    <div class="welcome-message">
      <h2>AV Equipment Entry Form</h2>
      <p>Welcome, <?php echo htmlspecialchars($_SESSION['username']); ?>!</p>
    </div>

    <form action="entryhandle.php" method="POST">
      <div class="form-group">
        <label>Name of the items</label>
        <input type="text" name="item_name" required>
      </div>

      <div class="form-group">
        <label>Make & Model</label>
        <input type="text" name="make_model" required>
      </div>

      <div class="form-group">
        <label>Quantity</label>
        <input type="number" name="quantity" required>
      </div>

      <div class="form-group">
        <label>Codec - Serial No.</label>
        <input type="text" name="codec_serial_no">
      </div>

      <div class="form-group">
        <label>Camera</label>
        <input type="text" name="camera">
      </div>

      <div class="form-group">
        <label>Mic</label>
        <input type="text" name="mic">
      </div>

      <div class="date-group">
        <div class="form-group">
          <label>CAMC Start Date</label>
          <input type="date" name="camc_start_date" required>
        </div>
        <div class="form-group">
          <label>CAMC End Date</label>
          <input type="date" name="camc_end_date" required>
        </div>
      </div>

      <!-- Updated Dropdown Field -->
      <div class="form-group">
        <label>Warranty/CAMC</label>
        <select name="warranty_camc" required>
  <option value="">-- Select --</option>
  <option value="Warranty">Warranty</option>
  <option value="CAMC">CAMC</option>
</select>
      </div>

      <div class="form-group">
        <label>Room No.</label>
        <input type="text" name="room_no">
      </div>

      <div class="form-group">
        <label>Any Additional Info</label>
        <textarea name="additional_info" rows="4"></textarea>
      </div>

      <div class="button-group">
        <div>
          <a href="view.php" class="btn btn-secondary">View Entries</a>
          <a href="logout.php" class="btn btn-danger">Logout</a>
        </div>
        <button type="submit" class="btn btn-primary">Submit</button>
      </div>
    </form>
  </div>
</body>
</html>
