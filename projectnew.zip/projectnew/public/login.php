<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Login</title>
  <link rel="stylesheet" href="style1.css" />
</head>
<body>
  <section class="main-container">
    <div class="login-box">
      <form id="loginForm" method="POST" action="lhandle.php">
        <h1> LOGIN </h1>

        <div class="input-box">
          <label>Username *</label>
          <input type="text" name="username" required placeholder="Enter your Username" />
        </div>

        <div class="input-box">
          <label>Password *</label>
          <input type="password" name="password" required placeholder="Enter your Password" />
        </div>

        <div class="input-box captcha-box">
          <label>Enter CAPTCHA</label>
          <div class="captcha-container">
            <span id="captchaText"></span>
            <button type="button" onclick="generateCaptcha()" class="refresh-btn">↻</button>
          </div>
          <input type="text" id="captchaInput" placeholder="Type above text" required />
          <p id="captchaError">Incorrect CAPTCHA</p>
        </div>

        <div class="remember-box">
          <input type="checkbox" id="remember" />
          <label for="remember">Remember me</label>
        </div>

        <button type="submit" class="login-btn">Login</button>

        
      </form>
    </div>

    <!-- Decorative Background -->
    <div class="circle purple" style="top: 60px; left: 60px;"></div>
    <div class="circle purple" style="top: 90px; left: 150px; width: 10px; height: 10px;"></div>
    <div class="circle yellow" style="bottom: 130px; right: 200px;"></div>
    <div class="circle purple" style="bottom: 100px; right: 100px; width: 12px; height: 12px;"></div>

    <div class="wave"></div>
  </section>

  <script>
    let captcha = "";

    function generateCaptcha() {
      captcha = Math.random().toString(36).substring(2, 8);
      document.getElementById("captchaText").innerText = captcha;
      document.getElementById("captchaError").style.display = "none";
    }

    document.getElementById("loginForm").addEventListener("submit", function(e) {
      if (document.getElementById("captchaInput").value !== captcha) {
        e.preventDefault();
        document.getElementById("captchaError").style.display = "block";
      }
    });

    window.onload = generateCaptcha;
  </script>
</body>
</html>
