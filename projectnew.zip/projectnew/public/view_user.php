<?php
session_start();
require_once __DIR__ . '/../config/database.php';

if (!isset($_SESSION['username']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../login.php");
    exit;
}

$user = $_GET['user'] ?? '';
if (!$user) {
    header("Location: admindashboard.php");
    exit;
}

try {
    $stmt = $pdo->prepare("SELECT * FROM devicesdetails WHERE submitted_by = ? ORDER BY user_entry_no ASC");
    $stmt->execute([$user]);
    $entries = $stmt->fetchAll();
} catch (PDOException $e) {
    exit("⚠️ Database error: " . $e->getMessage());
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Entries by <?= htmlspecialchars($user) ?></title>
    <style>
        body { font-family: Arial, sans-serif; }
        h1 { text-align: center; }
        table { border-collapse: collapse; width: 95%; margin: 20px auto; }
        th, td { border: 1px solid #999; padding: 8px 12px; text-align: center; }
        th { background-color: #d0f0ff; }
        .edit { background-color: #ffc107; color: #000; padding: 6px 10px; border-radius: 4px; text-decoration: none; }
        .edit-btn { background-color: #dc3545; color: #fff; padding: 6px 10px; border-radius: 4px; text-decoration: none; }
    </style>
</head>
<body>
<h1>Entries by <?= htmlspecialchars($user) ?></h1>
<table>
    <tr>
        <th>S.No</th>
        <th>Name</th>
        <th>Make/Model</th>
        <th>Quantity</th>
        <th>Codec</th>
        <th>Camera</th>
        <th>Mic</th>
        <th>Start Date</th>
        <th>End Date</th>
        <th>Warranty/CAMC</th>
        <th>Room No</th>
        <th>Additional Info</th>
        <th>Edit</th>
        <th>Delete</th>
    </tr>
    <?php foreach ($entries as $row): ?>
    <tr>
        <td><?= htmlspecialchars($row['user_entry_no']) ?></td>
        <td><?= htmlspecialchars($row['name']) ?></td>
        <td><?= htmlspecialchars($row['make_model']) ?></td>
        <td><?= htmlspecialchars($row['quantity']) ?></td>
        <td><?= htmlspecialchars($row['codec']) ?></td>
        <td><?= htmlspecialchars($row['camera']) ?></td>
        <td><?= htmlspecialchars($row['mic']) ?></td>
        <td><?= htmlspecialchars($row['Sdate']) ?></td>
        <td><?= htmlspecialchars($row['Edate']) ?></td>
        <td><?= htmlspecialchars($row['CAMC']) ?></td>
        <td><?= htmlspecialchars($row['Room_no']) ?></td>
        <td><?= htmlspecialchars($row['additional_info']) ?></td>
        <td><a href="../edit.php?sno=<?= $row['sno'] ?>" class="edit">Edit</a></td>
        <td><a href="../admindashboard.php?delete_id=<?= $row['sno'] ?>" class="edit-btn" onclick="return confirm('Are you sure?')">Delete</a></td>
    </tr>
    <?php endforeach; ?>
</table>
<a href="admindashboard.php" class="btn" style="display: block; text-align: center; margin-top: 20px;">Back to Dashboard</a>
</body>
</html>