<?php
session_start();
require_once __DIR__ . '/../config/database.php';

// Admin authentication check
if (!isset($_SESSION['username'])) {
    header("Location: ../login.php");
    exit;
}

if ($_SESSION['role'] !== 'admin') {
    header("Location: ../entry.php");
    exit;
}

// Handle CSV export
if (isset($_GET['export_csv'])) {
    header('Content-Type: text/csv');
    header('Content-Disposition: attachment; filename="devices_export_'.date('Y-m-d').'.csv"');

    $output = fopen('php://output', 'w');
    fputcsv($output, ['Sno', 'Name', 'Make/Model', 'Quantity', 'Codec', 'Camera',
                     'Mic', 'Start Date', 'End Date', 'CAMC', 'Room No',
                     'Additional Info', 'Submitted By', 'User Entry No']);

    if ($_GET['export_csv'] !== 'all') {
        $stmt = $pdo->prepare("SELECT * FROM devicesdetails WHERE submitted_by = ?");
        $stmt->execute([$_GET['export_csv']]);
    } else {
        $stmt = $pdo->query("SELECT * FROM devicesdetails");
    }

    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
        fputcsv($output, $row);
    }
    fclose($output);
    exit;
}

// Handle entry deletion
if (isset($_GET['delete_id'])) {
    $stmt = $pdo->prepare("DELETE FROM devicesdetails WHERE sno = ?");
    $stmt->execute([$_GET['delete_id']]);
    $_SESSION['message'] = "Entry deleted successfully!";
    header("Location: admindashboard.php");
    exit;
}

// Get all equipment entries
$devices = $pdo->query("SELECT * FROM devicesdetails ORDER BY sno DESC")->fetchAll();

// Get user statistics for pie chart
$userStats = $pdo->query("
    SELECT submitted_by, COUNT(*) as entry_count 
    FROM devicesdetails 
    WHERE submitted_by IS NOT NULL 
    GROUP BY submitted_by
")->fetchAll();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f5f5f5;
        }
        .admin-header {
            background-color: #343a40;
            color: white;
            padding: 15px 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .container {
            display: flex;
            margin: 20px;
            gap: 20px;
        }
        .sidebar {
            width: 250px;
            background: white;
            padding: 15px;
            border-radius: 5px;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
        }
        .main-content {
            flex: 1;
            background: white;
            padding: 20px;
            border-radius: 5px;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        th, td {
            border: 1px solid #ddd;
            padding: 8px 12px;
            text-align: left;
        }
        th {
            background-color: #d0f0ff;
        }
        .btn {
            padding: 5px 10px;
            text-decoration: none;
            border-radius: 3px;
            font-size: 14px;
            display: inline-flex;
            align-items: center;
            gap: 5px;
            cursor: pointer;
        }
        .btn-primary { background-color: #007bff; color: white; }
        .btn-danger { background-color: #dc3545; color: white; }
        .btn-success { background-color: #28a745; color: white; }

        .chart-container {
            width: 100%;
            max-width: 400px;
            margin: 20px auto;
        }
        .action-btns {
            display: flex;
            gap: 5px;
        }
        .alert {
            padding: 10px;
            margin-bottom: 15px;
            border-radius: 4px;
        }
        .alert-success {
            background-color: #d4edda;
            color: #155724;
        }

        /* Dropdown menu */
        .dropdown {
            display: none;
            position: absolute;
            background-color: #ffffff;
            box-shadow: 0px 2px 10px rgba(0,0,0,0.15);
            list-style-type: none;
            margin: 0;
            padding: 0;
            left: 0;
            top: 100%;
            z-index: 1000;
            width: 200px;
            border-radius: 5px;
        }
        .dropdown li a {
            display: block;
            padding: 8px 12px;
            color: #333;
            text-decoration: none;
        }
        .dropdown li a:hover {
            background-color: #f0f0f0;
        }
    </style>
</head>
<body>
    <div class="admin-header">
        <h2>Admin Dashboard</h2>
        <div>
            <span style="margin-right: 15px;">Welcome, <?= htmlspecialchars($_SESSION['username']) ?></span>
            <a href="logout.php" class="btn btn-danger">
                <i class="bi bi-box-arrow-right"></i> Logout
            </a>
        </div>
    </div>

    <div class="container">
        <div class="sidebar">
            <h3>Admin Menu</h3>
            <ul style="list-style: none; padding: 0;">
                <li style="margin-bottom: 10px;">
                    <a href="admindashboard.php" class="btn" style="justify-content: start;">
                        <i class="bi bi-table"></i> All Entries
                    </a>
                </li>

                <!-- Export CSV Dropdown -->
                <li style="margin-bottom: 10px; position: relative;">
                    <a onclick="toggleDropdown('exportDropdown')" class="btn" style="justify-content: start;">
                        <i class="bi bi-download"></i> Export CSV ▼
                    </a>
                    <ul id="exportDropdown" class="dropdown">
                        <li><a href="?export_csv=all">All Entries</a></li>
                        <li><a href="?export_csv=user1">User1</a></li>
                        <li><a href="?export_csv=user2">User2</a></li>
                        <li><a href="?export_csv=user3">User3</a></li>
                        <li><a href="?export_csv=user4">User4</a></li>
                        <li><a href="?export_csv=user5">User5</a></li>
                    </ul>
                </li>

                <!-- User View Dropdown -->
                <li style="margin-bottom: 10px; position: relative;">
                    <a onclick="toggleDropdown('userDropdown')" class="btn" style="justify-content: start;">
                        <i class="bi bi-eye"></i> User View ▼
                    </a>
                    <ul id="userDropdown" class="dropdown">
                        <li><a href="view.php?user=user1">User1</a></li>
                        <li><a href="view.php?user=user2">User2</a></li>
                        <li><a href="view.php?user=user3">User3</a></li>
                        <li><a href="view.php?user=user4">User4</a></li>
                        <li><a href="view.php?user=user5">User5</a></li>
                    </ul>
                </li>

                <li style="margin-bottom: 10px;">
                    <a href="entry.php" class="btn" style="justify-content: start;">
                        <i class="bi bi-plus-circle"></i> Create Entry
                    </a>
                </li>
            </ul>

            <div style="margin-top: 30px;">
                <h3>User Statistics</h3>
                <div class="chart-container">
                    <canvas id="userChart"></canvas>
                </div>
            </div>
        </div>

        <div class="main-content">
            <?php if (isset($_SESSION['message'])): ?>
                <div class="alert alert-success"><?= $_SESSION['message'] ?></div>
                <?php unset($_SESSION['message']); ?>
            <?php endif; ?>

            <h3>All Equipment Entries</h3>
            <div style="overflow-x: auto;">
                <table>
                    <thead>
                        <tr>
                        <th>S.No</th>
                        <th>Name</th>
                        <th>Make&Model</th>
                        <th>Quantity</th>
                        <th>Submitted by</th>
                        <th>Codec</th>
                        <th>Camera</th>
                        <th>Mic</th>
                        <th>Start Date</th>
                        <th>End Date</th>
                        <th>Warranty/CAMC</th>
                        <th>Room No</th>
                        <th>Additional Info</th>
                        <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $counter = 1; ?>
<?php foreach ($devices as $device): ?>
<tr>
    <td><?= $counter++ ?></td>
    <td><?= htmlspecialchars($device['name']) ?></td>
    <td><?= htmlspecialchars($device['make_model']) ?></td>
    <td><?= htmlspecialchars($device['quantity']) ?></td>
    <td><?= htmlspecialchars($device['submitted_by']) ?></td>
    <td><?= htmlspecialchars($device['codec']) ?></td>
    <td><?= htmlspecialchars($device['camera']) ?></td>
    <td><?= htmlspecialchars($device['mic']) ?></td>
    <td><?= date('d M Y', strtotime($device['Sdate'])) ?></td>
    <td><?= date('d M Y', strtotime($device['Edate'])) ?></td>
    <td><?= htmlspecialchars($device['CAMC']) ?></td>
    <td><?= htmlspecialchars($device['Room_no']) ?></td>
    <td><?= htmlspecialchars($device['additional_info']) ?></td>
    <td class="action-btns">
        <a href="edit.php?sno=<?= $device['sno'] ?>" class="btn btn-primary">
            <i class="bi bi-pencil"></i> Edit
        </a>
        <a href="?delete_id=<?= $device['sno'] ?>" class="btn btn-danger" onclick="return confirm('Are you sure?')">
            <i class="bi bi-trash"></i> Delete
        </a>
    </td>
</tr>
<?php endforeach; ?>

                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <script>
        const ctx = document.getElementById('userChart').getContext('2d');
        const userChart = new Chart(ctx, {
            type: 'pie',
            data: {
                labels: [<?php foreach ($userStats as $stat) echo "'" . addslashes($stat['submitted_by']) . "',"; ?>],
                datasets: [{
                    data: [<?php foreach ($userStats as $stat) echo $stat['entry_count'] . ","; ?>],
                    backgroundColor: ['#FF6384', '#36A2EB', '#FFCE56', '#4BC0C0', '#9966FF', '#FF9F40', '#8AC249', '#EA5545']
                }]
            },
            options: {
                responsive: true,
                plugins: { legend: { position: 'right' } }
            }
        });

        function toggleDropdown(id) {
            const dropdown = document.getElementById(id);
            dropdown.style.display = dropdown.style.display === 'block' ? 'none' : 'block';
        }

        // Hide dropdowns when clicking outside
        window.addEventListener('click', function (e) {
            if (!e.target.closest('.btn')) {
                document.querySelectorAll('.dropdown').forEach(el => el.style.display = 'none');
            }
        });
    </script>
</body>
</html>
