 let currentCaptcha = "";
        
        function generateCaptcha() {
            const chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
            currentCaptcha = "";
            for (let i = 0; i < 6; i++) {
                currentCaptcha += chars.charAt(Math.floor(Math.random() * chars.length));
            }
            document.getElementById("captcha").innerText = currentCaptcha;
            document.getElementById("captchaError").style.display = "none";
        }

        // Generate on page load
        window.onload = generateCaptcha;

        // Form submission handler
        document.getElementById("loginForm").addEventListener("submit", function(e) {
            e.preventDefault();
            
            const userInput = document.getElementById("captchaInput").value;
            const errorElement = document.getElementById("captchaError");
            
            // Validate CAPTCHA
            if (userInput !== currentCaptcha) {
                errorElement.style.display = "block";
                document.getElementById("captchaInput").classList.add("shake");
                setTimeout(() => {
                    document.getElementById("captchaInput").classList.remove("shake");
                }, 500);
                
                // Refresh CAPTCHA
                generateCaptcha();
                document.getElementById("captchaInput").value = "";
                document.getElementById("captchaInput").focus();
                return false;
            }
            
            // If CAPTCHA is correct, proceed with login
            errorElement.style.display = "none";
            alert("Login successful!");
            // Here you would normally submit the form to your server
            // this.submit();
        });