<?php
session_start();
require_once __DIR__ . '/../config/database.php';

// Check login
$currentUser = $_SESSION['username'] ?? '';
$role = $_SESSION['role'] ?? '';

if (!$currentUser) {
    exit("❌ Not logged in.");
}

// Determine whose entries to fetch
$targetUser = $currentUser;

if ($role === 'admin' && isset($_GET['user']) && $_GET['user'] !== '') {
    $targetUser = $_GET['user'];
}

try {
    $stmt = $pdo->prepare("SELECT * FROM devicesdetails WHERE submitted_by = ? ORDER BY user_entry_no ASC");
    $stmt->execute([$targetUser]);
    $entries = $stmt->fetchAll();
} catch (PDOException $e) {
    exit("⚠️ Database error: " . $e->getMessage());
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>View AV Entries</title>
    <style>
        body {
            font-family: Arial, sans-serif;
        }

        h1 {
            text-align: center;
        }

        .top-buttons {
            position: absolute;
            top: 20px;
            right: 30px;
        }

        .btn {
            display: inline-block;
            padding: 8px 16px;
            margin-left: 10px;
            background-color: #28a745;
            color: white;
            text-decoration: none;
            border-radius: 4px;
            font-weight: bold;
            transition: background-color 0.3s ease;
        }

        .btn:hover {
            background-color: #1e7e34;
        }

        table {
            border-collapse: collapse;
            width: 95%;
            margin: 80px auto 30px;
        }

        th, td {
            border: 1px solid #999;
            padding: 8px 12px;
            text-align: center;
        }

        th {
            background-color: #d0f0ff;
        }

        .edit {
            background-color: #ffc107;
            color: #000;
            padding: 6px 10px;
            font-weight: bold;
            border-radius: 4px;
            text-decoration: none;
        }

        .edit-btn {
            background-color: #dc3545;
            color: #fff;
            padding: 6px 10px;
            font-weight: bold;
            border-radius: 4px;
            text-decoration: none;
        }
    </style>
</head>
<body>

<div class="top-buttons">
    <a href="download.php<?= $role === 'admin' && isset($_GET['user']) ? '?user=' . urlencode($_GET['user']) : '' ?>" class="btn">Download All</a>
    <a href="entry.php" class="btn">Fill Another Form</a>
    <a href="logout.php" class="btn">Logout</a>
</div>

<h1>
    Entries by <?= htmlspecialchars($targetUser) ?>
</h1>

<table>
    <tr>
        <th>S.No</th>
        <th>Name</th>
        <th>Make/Model</th>
        <th>Quantity</th>
        <th>Codec</th>
        <th>Camera</th>
        <th>Mic</th>
        <th>Start Date</th>
        <th>End Date</th>
        <th>Warranty/CAMC</th>
        <th>Room No</th>
        <th>Additional Info</th>
        <th>Edit</th>
        <th>Delete</th>
    </tr>

    <?php foreach ($entries as $row): ?>
    <tr>
        <td><?= htmlspecialchars($row['user_entry_no']) ?></td>
        <td><?= htmlspecialchars($row['name']) ?></td>
        <td><?= htmlspecialchars($row['make_model']) ?></td>
        <td><?= htmlspecialchars($row['quantity']) ?></td>
        <td><?= htmlspecialchars($row['codec']) ?></td>
        <td><?= htmlspecialchars($row['camera']) ?></td>
        <td><?= htmlspecialchars($row['mic']) ?></td>
        <td><?= htmlspecialchars($row['Sdate']) ?></td>
        <td><?= htmlspecialchars($row['Edate']) ?></td>
        <td><?= htmlspecialchars($row['CAMC']) ?></td>
        <td><?= htmlspecialchars($row['Room_no']) ?></td>
        <td><?= htmlspecialchars($row['additional_info']) ?></td>
        <td>
            <a href="edit.php?sno=<?= $row['sno'] ?>" class="edit">Edit</a>
        </td>
        <td>
            <a href="delete.php?sno=<?= $row['sno'] ?>" class="edit-btn" onclick="return confirm('Are you sure you want to delete this entry?')">Delete</a>
        </td>
    </tr>
    <?php endforeach; ?>
</table>

</body>
</html>
