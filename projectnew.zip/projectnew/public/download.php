<?php
require_once __DIR__ . '/../config/database.php'; // ✅ Corrected __DIR__

header('Content-Type: text/csv');
header('Content-Disposition: attachment;filename="devices_export.csv"');

$output = fopen('php://output', 'w');

// ✅ CSV column headers
fputcsv($output, ['Sno', 'Name', 'Make/Model', 'Quantity', 'Codec', 'Camera', 'Mic', 'Start Date', 'End Date', 'Warranty/CAMC', 'Room No', 'Additional Info']);

// ✅ Correct table name
$stmt = $pdo->query("SELECT * FROM devicesdetails");

while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
    fputcsv($output, [
        $row['sno'],
        $row['name'],
        $row['make_model'],
        $row['quantity'],
        $row['codec'],
        $row['camera'],
        $row['mic'],
        $row['Sdate'],
        $row['Edate'],
        $row['CAMC'],
        $row['Room_no'],
        $row['additional_info']
    ]);
}

fclose($output);
exit;
?>
