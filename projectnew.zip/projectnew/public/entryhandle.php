<?php
session_start();
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

require_once __DIR__ . '/../config/database.php';

$submitted_by = $_SESSION['username'] ?? '';
if (!$submitted_by) {
    exit("❌ You are not logged in.");
}

$stmtCount = $pdo->prepare("SELECT COUNT(*) FROM devicesdetails WHERE submitted_by = ?");
$stmtCount->execute([$submitted_by]);
$user_entry_no = $stmtCount->fetchColumn() + 1;

// Sanitize and assign input values
$name             = htmlspecialchars(trim($_POST['item_name'] ?? ''));
$make_model       = htmlspecialchars(trim($_POST['make_&_model'] ?? ''));
$quantity         = (int) ($_POST['Quantity'] ?? 0);
$codec_serial_no  = htmlspecialchars(trim($_POST['Codec_seial_no'] ?? ''));
$camera           = htmlspecialchars(trim($_POST['camera'] ?? ''));
$mic              = htmlspecialchars(trim($_POST['Mic'] ?? ''));
$camc_start_date  = $_POST['camc_start_date'] ?? '';
$warranty_expires = $_POST['Warranty_Expires'] ?? '';
$warranty_camc    = htmlspecialchars(trim($_POST['warranty_camc']?? ''));
$room_no          = htmlspecialchars(trim($_POST['Room_no'] ?? ''));
$additional_info  = htmlspecialchars(trim($_POST['Any_Additional_Info'] ?? ''));

try {
    // Remove 'sno' (auto-increment)
    $stmt = $pdo->prepare("
        INSERT INTO devicesdetails (
            name, make_model, quantity,
            codec, camera, mic,
            Sdate, Edate,
            CAMC, Room_no, additional_info,
            submitted_by, user_entry_no
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    ");

    $stmt->execute([
        $name,
        $make_model,
        $quantity,
        $codec_serial_no,
        $camera,
        $mic,
        $camc_start_date,
        $warranty_expires,
        $warranty_camc,
        $room_no,
        $additional_info,
        $submitted_by,
        $user_entry_no
    ]);

    echo "<div style='
        font-family: sans-serif;
        padding: 20px;
        background: #e0ffef;
        border: 2px solid #00ffe0;
        box-shadow: 0 0 10px rgb(11, 16, 16);
        border-radius: 8px;
        width: fit-content;
        margin: 40px auto;
        text-align: center;
    '>
        ✅ <strong>Entry recorded successfully!</strong><br><br>
        <a href='entry.php' style='
            color: #00ffe0;
            text-decoration: none;
            font-weight: bold;
        '>← Fill Another Form</a><br>

         <a href='view.php' style='
            color: #00ffe0;
            text-decoration: none;
            font-weight: bold;
        '>← View Entries</a><br>

        <a href='logout.php' style='
            color: #00ffe0;
            text-decoration: none;
            font-weight: bold;
        '> Logout</a>
    </div>";
} catch (PDOException $e) {
    exit("⚠️ Database error: " . $e->getMessage());
}
