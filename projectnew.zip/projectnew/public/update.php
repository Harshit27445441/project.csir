<?php
session_start();
require_once __DIR__ . '/../config/database.php';

if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit();
}

$sno = $_POST['sno'] ?? null;

if (!$sno || !is_numeric($sno)) {
    exit("❌ Invalid or missing sno.");
}

// Get form data
$name = $_POST['item_name'] ?? '';
$makeModel = $_POST['make_model'] ?? '';
$quantity = $_POST['quantity'] ?? 0;
$codec = $_POST['codec_serial_no'] ?? '';
$camera = $_POST['camera'] ?? '';
$mic = $_POST['mic'] ?? '';
$sdate = $_POST['camc_start_date'] ?? '';
$edate = $_POST['warranty_expires'] ?? '';
$camc = $_POST['warranty_camc'] ?? '';
$room = $_POST['room_no'] ?? '';
$additional = $_POST['additional_info'] ?? '';

// Update the entry
try {
    $stmt = $pdo->prepare("
        UPDATE devicesdetails
        SET 
            name = ?, 
            make_model = ?, 
            quantity = ?, 
            codec = ?, 
            camera = ?, 
            mic = ?, 
            Sdate = ?, 
            Edate = ?, 
            CAMC = ?, 
            Room_no = ?, 
            additional_info = ?
        WHERE sno = ?
    ");

    $stmt->execute([
        $name, $makeModel, $quantity, $codec, $camera, $mic,
        $sdate, $edate, $camc, $room, $additional, $sno
    ]);

    // ✅ Redirect based on user role
    if ($_SESSION['role'] === 'admin') {
        header("Location: admindashboard.php");
    } else {
        header("Location: view.php");
    }
    exit;

} catch (PDOException $e) {
    exit("⚠️ Database error: " . $e->getMessage());
}
