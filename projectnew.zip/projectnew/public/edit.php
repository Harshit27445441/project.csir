<?php
session_start();
if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit();
}

require_once __DIR__ . '/../config/database.php';

$sno = $_GET['sno'] ?? null;

if (!$sno || !is_numeric($sno)) {
    exit("❌ Invalid or missing sno.");
}

try {
    // Fetch the entry by sno
    $stmt = $pdo->prepare("SELECT * FROM devicesdetails WHERE sno = ?");
    $stmt->execute([$sno]);
    $device = $stmt->fetch();

    if (!$device) {
        exit("❌ No entry found with Sno: $sno");
    }
} catch (PDOException $e) {
    exit("⚠️ Database error: " . $e->getMessage());
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <title>Edit Entry</title>
  <link rel="stylesheet" href="style3.css">
</head>
<body>

<div class="form-container">
  <h2>Edit AV Entry (Sno: <?= htmlspecialchars($sno) ?>)</h2>

  <form action="update.php" method="POST">
    <input type="hidden" name="sno" value="<?= $sno ?>">

    <div class="form-group">
      <label>Name of the Item</label>
      <input type="text" name="item_name" value="<?= htmlspecialchars($device['name']) ?>" required />
    </div>

    <div class="form-group">
      <label>Make & Model</label>
      <input type="text" name="make_model" value="<?= htmlspecialchars($device['make_model']) ?>" required />
    </div>

    <div class="form-group">
      <label>Quantity</label>
      <input type="number" name="quantity" value="<?= htmlspecialchars($device['quantity']) ?>" required />
    </div>

    <div class="form-group">
      <label>Codec - Serial No.</label>
      <input type="text" name="codec_serial_no" value="<?= htmlspecialchars($device['codec']) ?>" />
    </div>

    <div class="form-group">
      <label>Camera</label>
      <input type="text" name="camera" value="<?= htmlspecialchars($device['camera']) ?>" />
    </div>

    <div class="form-group">
      <label>Mic</label>
      <input type="text" name="mic" value="<?= htmlspecialchars($device['mic']) ?>" />
    </div>

    <div class="date-right">
      <div class="form-group">
        <label>CAMC Start Date</label>
        <input type="date" name="camc_start_date" value="<?= htmlspecialchars($device['Sdate']) ?>" required />
      </div>
      <div class="form-group">
        <label>Warranty Expires</label>
        <input type="date" name="warranty_expires" value="<?= htmlspecialchars($device['Edate']) ?>" required />
      </div>
    </div>

    <div class="form-group">
        <label>Warranty/CAMC</label>
        <select name="warranty_camc" required>
  <option value="">-- Select --</option>
  <option value="Warranty">Warranty</option>
  <option value="CAMC">CAMC</option>
</select>

      </div>
    <div class="form-group">
      <label>Room No.</label>
      <input type="text" name="room_no" value="<?= htmlspecialchars($device['Room_no']) ?>" />
    </div>

    <div class="form-group">
      <label>Any Additional Info</label>
      <textarea name="additional_info" rows="4"><?= htmlspecialchars($device['additional_info']) ?></textarea>
    </div>
<div class="button-group">
  <button type="submit" class="btn-primary">Update</button>
  <a href="view.php" class="btn-secondary">Cancel</a>
</div>

  </form>
</div>

</body>
</html>
