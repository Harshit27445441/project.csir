<?php
session_start();
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

require_once __DIR__ . '/../config/database.php';

$username = $_POST['username'] ?? '';
$password = $_POST['password'] ?? '';

if (!$username || !$password) {
    exit('❌ Missing username or password');
}

$stmt = $pdo->prepare("SELECT * FROM logindetails WHERE username = ?");
$stmt->execute([$username]);
$user = $stmt->fetch();

if (!$user) {
    exit("❌ Username not found in database");
}

if ($password === $user['password']) {
    $_SESSION['username'] = $user['username'];
    $_SESSION['role'] = $user['role'];

    if ($user['role'] === 'admin') {
        header("Location: admindashboard.php");
    } else {
        header("Location: entry.php");
    }
    exit();
} else {
    exit("❌ Incorrect password");
}
