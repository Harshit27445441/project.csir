<?php
require_once __DIR__ . '/../config/database.php'; // ✅ Corrected __DIR__

if (isset($_GET['sno']) && is_numeric($_GET['sno'])) {
    $sno = $_GET['sno'];

    // ✅ Fixed table name
    $stmt = $pdo->prepare("DELETE FROM devicesdetails WHERE sno = ?");
    $stmt->execute([$sno]);
}

// ✅ Redirect back to view page
header("Location: view.php");
exit;
?>
